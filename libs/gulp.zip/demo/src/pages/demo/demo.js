/*
 * @Author       : Evan.G
 * @Date         : 2021-07-22 16:32:33
 * @LastEditTime: 2021-10-25 17:55:24
 * @Description  :
 */
(function () {
    // window.location.href= window.location.href
    //模板字符串
    const obj = {
        name: "Evan",
        age: 17,
    };
    let template = `姓名叫${obj.name}，年龄${obj.age}岁`;
    console.log("模板字符串", template);

    //解构表达式
    let arr = [1, 9];
    let [x, y] = arr;
    console.log("解构表达式", x, y);

    //for..of 循环
    let arr2 = [1, 2, 3, 4, 5];
    for (let item of arr2) {
        console.log("for..of 循环", item);
    }

    //展开运算符
    let a = [3, 4, 5];
    let b = [1, 2, ...a];
    console.log(b);

    //箭头函数
    setTimeout(() => {
        console.log("open!");
    }, 1000);

    window.fm = hope.form({
        ele: "#form",
        on: {
            submit: function (e) {
                console.log(e);
            },
        },
        controls: {
            city: {
                type: "select",
                options: {},
                on: {
                    init: function (e) {
                        console.log(e);
                    },
                    change: function (e) {
                        console.log(e);
                    },
                    toggle: function (e) {
                        console.log(e);
                    },
                },
                verify: function (value) {
                    if (value.length <= 0) {
                        return "请选择一个选项";
                    }
                },
            },
        },
    });
})();

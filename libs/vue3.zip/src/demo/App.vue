<!--
 * @Author       : Evan.G
 * @Date         : 2022-01-19 15:12:18
 * @LastEditTime : 2022-01-20 11:22:23
 * @Description  : 
-->
<template>
    <layout-header></layout-header>
    <router-view />
    <layout-footer></layout-footer>
</template>

<script>
export default {
    setup() {},
};
</script>

<style lang="less"></style>

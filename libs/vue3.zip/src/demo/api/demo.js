/*
 * @Author       : Evan.G
 * @Date         : 2021-12-24 15:47:00
 * @LastEditTime : 2021-12-30 15:09:37
 * @Description  :
 */
import { $http } from "@/utils/httpService";

// 登录
export const login = (params) => {
    return $http({
        url: `/data-api/screenUserManageController/login?userName=${params.userName}&password=${params.password}&rememberMe=${params.rememberMe}`,
        method: "POST",
        options: {
            data: {},
        },
    });
};

// 退出登录
export const logout = (params) => {
    return $http({
        url: `/data-api/user/logout`,
        method: "POST",
        options: {
            data: {},
        },
    });
};

<!--
 * @Author       : Evan.G
 * @Date         : 2022-01-19 15:26:08
 * @LastEditTime : 2022-01-19 16:44:48
 * @Description  : 
-->
<template>
    <div>头部</div>
</template>

<script>
export default {
    name: "layoutHeader",
    setup() {},
};
</script>

<style lang="less" scoped></style>

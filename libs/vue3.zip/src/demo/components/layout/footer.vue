<template>
    <div>底部</div>
</template>

<script>
export default {
    name: "layoutFooter",
    setup() {},
};
</script>

<style lang="less" scoped></style>

<template>
    <div>
        <mod :title="'我是名字'"></mod>
    </div>
</template>

<script>
import mod from "./components/module.vue";
export default {
    components: {
        mod,
    },
    setup() {},
};
</script>

<style lang="less" scoped></style>

(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;

            docEl.style.fontSize = 100 * (clientWidth / 1366) + 'px';
            console.log(docEl.style.fontSize);
        },
        addEventListener = function (ele, event, fn) {
            if (ele.addEventListener) {
                ele.addEventListener(event, fn, false);
            } else {
                ele.attachEvent('on' + event, fn.bind(ele));
            }
        }

    if (!Function.prototype.bind) {
        Function.prototype.bind = function () {
            if (typeof this !== 'function') {
                throw new TypeError(
                    'Function.prototype.bind - what is trying to be bound is not callable');
            }
            var _this = this;
            var obj = arguments[0];
            var ags = Array.prototype.slice.call(arguments, 1);
            return function () {
                _this.apply(obj, ags);
            };
        };
    }
    // if (!doc.addEventListener) return;
    addEventListener(win, resizeEvt, recalc);
    addEventListener(doc, 'DOMContentLoaded', recalc);
    recalc();
})(document, window);